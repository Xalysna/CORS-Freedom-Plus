﻿// common.js

// Extensión de Prototipos

// Extensión del prototipo de String para formateo similar a Python
String.prototype.formatUnicorn = String.prototype.formatUnicorn || function () {
    "use strict";
    var str = this.toString();
    if (arguments.length) {
        var t = typeof arguments[0];
        var key;
        var args = ("string" === t || "number" === t) ?
            Array.prototype.slice.call(arguments)
            : arguments[0];

        for (key in args) {
            str = str.replace(new RegExp("\\{" + key + "\\}", "gi"), args[key]);
        }
    }

    return str;
};

// Extensión del prototipo de String para convertir una cadena HTML en un elemento DOM
String.prototype.toElement = function () {
    const template = document.createElement("template");
    template.innerHTML = this;
    return template.content.firstElementChild;
}

// Extensión del prototipo de String para localización de cadenas
String.prototype.loc = function () {
    return chrome.i18n.getMessage(this) || this;
}

// Función para realizar la localización de todos los elementos con el atributo "data-loc"
function locAll() {
    document.querySelectorAll("[data-loc]:not([data-loc-done])").forEach(el => {
        const key = el.getAttribute("data-loc");
        el.innerHTML = key.loc();
        el.setAttribute("data-loc-done", "");
    });
}

// Extensión del prototipo de Node para crear un elemento hijo
Node.prototype.createElement = function (name) {
    const el = document.createElement(name);
    this.appendChild(el);
    return el;
}

// Extensión del prototipo de HTMLElement para agregar un script
HTMLElement.prototype.appendScript = function (source, isModule) {
    return new Promise(resolve => {
        let script = document.createElement('script');
        script.async = 1;
        if (isModule) {
            script.type = "module";
        }

        script.onload = script.onreadystatechange = function (_, isAbort) {
            if (isAbort || !script.readyState || /loaded|complete/.test(script.readyState)) {
                script.onload = script.onreadystatechange = null;
                script = undefined;

                if (!isAbort) {
                    resolve();
                }
            }
        };

        script.src = source;
        this.appendChild(script);
    });
}

// Extensión del prototipo de HTMLElement para delegación de eventos
HTMLElement.prototype.addDelegate = function (eventName, cssMatch, callback) {
    this.addEventListener(eventName, function (e) {
        for (let target = e.target; target && target != this; target = target.parentNode) {
            if (target.matches(cssMatch)) {
                callback(e, target);
                break;
            }
        }
    });
};

// Extensión del prototipo de HTMLElement para encontrar el atributo más cercano
HTMLElement.prototype.findClosestAttr = function (attr) {
    let el = this.closest(`[${attr}]`);

    return el ? el.getAttribute(attr) : null;
}

// Extensión del prototipo de HTMLElement para verificar si un elemento está deshabilitado
HTMLElement.prototype.isDisabled = function () {
    return this.closest(".disabled") || this.closest("[disabled]");
};

// Extensión del prototipo de HTMLElement para ocultar de manera exclusiva
HTMLElement.prototype.exclusiveDisplay = function () {
    var parent = this.parentElement;

    parent.childNodes.forEach(c => {
        if (c.classList) {
            c.classList.add("d-none");
        }
    });

    this.classList.remove("d-none");
};

// Extensión del prototipo de HTMLElement para hacer visible de manera exclusiva
HTMLElement.prototype.exclusiveVisibility = function () {
    var parent = this.parentElement;

    parent.childNodes.forEach(c => {
        if (c.classList) {
            c.classList.add("invisible");
        }
    });

    this.classList.remove("invisible");
};

// Extensión del prototipo de HTMLElement para establecer el estado deshabilitado
HTMLElement.prototype.setDisabled = function (disabled) {
    if (disabled) {
        this.setAttribute("disabled", "");
        this.classList.add("disabled");
    } else {
        this.removeAttribute("disabled");
        this.classList.remove("disabled");
    }
};

// Extensión del prototipo de HTMLElement para localización de cadenas dentro del elemento
HTMLElement.prototype.loc = function () {
    this.querySelectorAll("[data-loc]:not([data-loc-done])").forEach(el => {
        const key = el.getAttribute("data-loc");
        el.innerHTML = key.loc();
        el.setAttribute("data-loc-done", "");
    });
}
