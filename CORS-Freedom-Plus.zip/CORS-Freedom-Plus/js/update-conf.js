var ExtUpdateConf = {
    // installUrl: "https://github.com/Xavaya/CORS-Freedom-Plus",
    // uninstallUrl: "https://github.com/Xavaya/CORS-Freedom-Plus"
};
